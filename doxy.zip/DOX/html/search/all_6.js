var searchData=
[
  ['game_0',['Game',['../class_game.html',1,'']]],
  ['gamingpc_1',['GamingPc',['../class_gaming_pc.html',1,'']]],
  ['gpu_2',['Gpu',['../class_gpu.html',1,'']]]
];
