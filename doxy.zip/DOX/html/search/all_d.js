var searchData=
[
  ['operatingsystem_0',['OperatingSystem',['../class_operating_system.html',1,'']]],
  ['overheatexception_1',['OverheatException',['../class_overheat_exception.html',1,'']]]
];
