var searchData=
[
  ['структура_20репозитория_0',['Структура репозитория',['../dir_f69b27431d6b8e06bddc8ec652dbec9b.html#autotoc_md1',1,'']]],
  ['статистика_1',['Итоговая статистика',['../dir_f69b27431d6b8e06bddc8ec652dbec9b.html#autotoc_md5',1,'']]]
];
