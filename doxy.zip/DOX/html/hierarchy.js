var hierarchy =
[
    [ "BenchmarkResult", "class_benchmark_result.html", null ],
    [ "Clipboard", "class_clipboard.html", null ],
    [ "Connectable", "class_connectable.html", [
      [ "Display", "class_display.html", null ],
      [ "InputDevice", "class_input_device.html", [
        [ "Keyboard", "class_keyboard.html", null ],
        [ "Mouse", "class_mouse.html", null ]
      ] ],
      [ "NetworkCard", "class_network_card.html", [
        [ "WifiAdapter", "class_wifi_adapter.html", null ]
      ] ],
      [ "Printer", "class_printer.html", null ]
    ] ],
    [ "FileSystem", "class_file_system.html", null ],
    [ "Identifiable", "class_identifiable.html", [
      [ "Named", "class_named.html", [
        [ "Application", "class_application.html", [
          [ "Antivirus", "class_antivirus.html", null ],
          [ "Browser", "class_browser.html", null ],
          [ "Game", "class_game.html", null ]
        ] ],
        [ "Bios", "class_bios.html", null ],
        [ "Component", "class_component.html", [
          [ "Battery", "class_battery.html", null ],
          [ "CoolingSystem", "class_cooling_system.html", null ],
          [ "Display", "class_display.html", null ],
          [ "Gpu", "class_gpu.html", null ],
          [ "InputDevice", "class_input_device.html", null ],
          [ "Motherboard", "class_motherboard.html", null ],
          [ "NetworkCard", "class_network_card.html", null ],
          [ "PowerSupply", "class_power_supply.html", null ],
          [ "Printer", "class_printer.html", null ],
          [ "Processor", "class_processor.html", null ],
          [ "RamModule", "class_ram_module.html", null ],
          [ "Router", "class_router.html", null ],
          [ "StorageDevice", "class_storage_device.html", [
            [ "Hdd", "class_hdd.html", null ],
            [ "Ssd", "class_ssd.html", null ]
          ] ]
        ] ],
        [ "Computer", "class_computer.html", [
          [ "Desktop", "class_desktop.html", [
            [ "GamingPc", "class_gaming_pc.html", null ]
          ] ],
          [ "Laptop", "class_laptop.html", null ],
          [ "Server", "class_server.html", [
            [ "SecureServer", "class_secure_server.html", null ]
          ] ]
        ] ],
        [ "ComputerCase", "class_computer_case.html", null ],
        [ "Directory", "class_directory.html", null ],
        [ "Driver", "class_driver.html", null ],
        [ "File", "class_file.html", null ],
        [ "OperatingSystem", "class_operating_system.html", null ],
        [ "Process", "class_process.html", null ],
        [ "RepairTicket", "class_repair_ticket.html", null ],
        [ "Technician", "class_technician.html", null ],
        [ "User", "class_user.html", null ]
      ] ],
      [ "Powered", "class_powered.html", [
        [ "Component", "class_component.html", null ],
        [ "Computer", "class_computer.html", null ]
      ] ]
    ] ],
    [ "IpAddress", "class_ip_address.html", null ],
    [ "LogEntry", "class_log_entry.html", null ],
    [ "Logger", "class_logger.html", null ],
    [ "MemoryManager", "class_memory_manager.html", null ],
    [ "Monitorable", "class_monitorable.html", [
      [ "Gpu", "class_gpu.html", null ],
      [ "Hdd", "class_hdd.html", null ],
      [ "Processor", "class_processor.html", null ]
    ] ],
    [ "Permissions", "class_permissions.html", null ],
    [ "ProcessManager", "class_process_manager.html", null ],
    [ "std::runtime_error", null, [
      [ "ComputerException", "class_computer_exception.html", [
        [ "AuthenticationException", "class_authentication_exception.html", null ],
        [ "BootFailureException", "class_boot_failure_exception.html", null ],
        [ "DeviceNotConnectedException", "class_device_not_connected_exception.html", null ],
        [ "DiskFullException", "class_disk_full_exception.html", null ],
        [ "FileNotFoundException", "class_file_not_found_exception.html", null ],
        [ "IncompatibleComponentException", "class_incompatible_component_exception.html", null ],
        [ "InsufficientMemoryException", "class_insufficient_memory_exception.html", null ],
        [ "InvalidComponentDataException", "class_invalid_component_data_exception.html", null ],
        [ "InvalidIpAddressException", "class_invalid_ip_address_exception.html", null ],
        [ "NetworkUnavailableException", "class_network_unavailable_exception.html", null ],
        [ "OverheatException", "class_overheat_exception.html", null ],
        [ "PermissionDeniedException", "class_permission_denied_exception.html", null ],
        [ "PowerException", "class_power_exception.html", null ],
        [ "ProcessNotFoundException", "class_process_not_found_exception.html", null ]
      ] ]
    ] ],
    [ "Scheduler", "class_scheduler.html", null ],
    [ "Session", "class_session.html", null ],
    [ "Settings", "class_settings.html", null ],
    [ "UsbPort", "class_usb_port.html", null ],
    [ "Warranty", "class_warranty.html", null ]
];